//내장함수 eval()을 이용하여 입력된 식을 계산
function calculate(form){
	myform.expression.value=eval(myform.expression.value)	
	}
//입력된 숫자나 기호를 수식입력란에 입력
function enter_expr(form,str) {	
	myform.expression.value+=str	
	}
//입력된 수식을 지운다
function clear_expr(form) {
	myform.expression.value=""	
	}
//한문자씩 지우는 함수를 만든다
function back(form){
		myform.expression.value = myform.expression.value.slice(0,myform.expression.value.length-1);
}